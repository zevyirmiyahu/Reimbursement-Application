var baseURL = 'http://localhost:8080/zy-project1/';

/*
document.getElementById("submit").onclick = () => {
    console.log("Step1");
    let xhr = new XMLHttpRequest();
    console.log("Step2");
    xhr.open('POST', baseURL + 'RegistrationServlet');
    console.log("Step3");
    xhr.onreadystatechange = () => {
        if(xhr.readyState === 4 && xhr.status === 200) {
            let info = JSON.parse(xhr.responseText);
            console.log(info);
        }
    }
    xhr.send();
};
*/
