var baseURL = 'http://localhost:8080/zy-project1/';

window.onload = function () {
    var xhttp;
    xhttp = new XMLHttpRequest();
    xhttp.open("GET", baseURL + "ShowInfoServlet", true);
    xhttp.onreadystatechange = function () {
        if (xhttp.readyState === 4 && xhttp.status === 200) {

            let data = makeDataArray(xhttp.responseText);
            document.getElementById("table-firstname").innerHTML = data[0];
            document.getElementById("table-lastname").innerHTML = data[1];
            document.getElementById("table-address").innerHTML = data[2];
            document.getElementById("table-email").innerHTML = data[3];
            document.getElementById("table-phone").innerHTML = data[4];
            document.getElementById("table-manager").innerHTML = data[5];
        }
    };
    xhttp.send();
};

function makeDataArray(str) {
    str = str.slice(1, str.length - 1);
    let data = str.split(",");
    return data;
}

function popTable(user) {
    let newRow = document.createElement('tr');

    let idCol = document.createElement('td');
    idCol.innerText = user[0]; //.id
    let nameCol = document.createElement('td');
    nameCol.innerText = user[1] //.firstName;
    let levelCol = document.createElement('td');
    levelCol.innerText = user[2] //.lastName;
    let classCol = document.createElement('td');
    classCol.innerText = user[3] //.phone;

    newRow.appendChild(idCol);
    newRow.appendChild(nameCol);
    newRow.appendChild(levelCol);
    newRow.appendChild(classCol);
    document.getElementById('infoTable').appendChild(newRow);
}

function resetTable() {
    let table = document.getElementById('infoTable');
    while (table.firstChild) {
        table.removeChild(table.firstChild);
    }
}