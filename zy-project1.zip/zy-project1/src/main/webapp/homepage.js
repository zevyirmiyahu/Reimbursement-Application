(function(){
    document.getElementById("request-form").style.visibility = "hidden";
    document.getElementById("request-information").style.visibility = "hidden";
    document.getElementById("user-information").style.visibility = "hidden";
})();

// shows/hides request-form
function elementHidder1() {
    let e = document.getElementById("request-form");
    if(e.style.visibility === "hidden") {
        e.style.visibility = "visible";
    }
    else {
        e.style.visibility = "hidden";
    }
}

// shows/hides request-information
function elementHidder2() {
    let e = document.getElementById("request-information");
    if(e.style.visibility === "hidden") {
        e.style.visibility = "visible";
    }
    else {
        e.style.visibility = "hidden";
    }
}

// shows/hides user-information
function elementHidder3() {
    let e = document.getElementById("user-information");
    if(e.style.visibility === "hidden") {
        e.style.visibility = "visible";
    }
    else {
        e.style.visibility = "hidden";
    }
}