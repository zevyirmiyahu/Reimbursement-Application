package com.zevyirmiyahu.dao;

import com.zevyirmiyahu.beans.ReimburstmentRequest;

public interface ReimburstmentRequestDao {
	public void submitReimburstmentRequest(ReimburstmentRequest request);
}
