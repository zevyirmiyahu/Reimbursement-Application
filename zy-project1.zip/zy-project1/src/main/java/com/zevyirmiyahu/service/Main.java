package com.zevyirmiyahu.service;

import com.zevyirmiyahu.beans.ReimburstmentRequest;
import com.zevyirmiyahu.beans.User;
import com.zevyirmiyahu.daoImpl.ReimburstmentRequestDaoImpl;
import com.zevyirmiyahu.daoImpl.UserDaoImpl;

public class Main {
	
	public static void main(String[] args) {
		//Service svc = new Service();
		//UserDaoImpl udi = new UserDaoImpl();
		//ReimburstmentRequestDaoImpl rdi = new ReimburstmentRequestDaoImpl();
		//rdi.submitReimburstmentRequest(new ReimburstmentRequest(10, "03-30-2019", 1, 1, "gas"));
		//udi.createUser(new User(false, "Zev", "Yirmiyahu", "0012 sugar star Rd", "908-444-0011", "zy@email", "yikes"));
		
	}
}
