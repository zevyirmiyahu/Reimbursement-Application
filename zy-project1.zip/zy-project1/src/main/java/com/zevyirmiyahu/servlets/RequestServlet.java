package com.zevyirmiyahu.servlets;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zevyirmiyahu.beans.ReimburstmentRequest;
import com.zevyirmiyahu.daoImpl.ReimburstmentRequestDaoImpl;
import com.zevyirmiyahu.service.Service;

public class RequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RequestServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int amount = Integer.parseInt(request.getParameter("Amount"));
		String date = request.getParameter("date");
		String description = request.getParameter("description");
		byte[] imageBytes = (request.getParameter("image")).getBytes();
		Blob blob = null;
		try {
			blob.setBytes(0, imageBytes);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ReimburstmentRequestDaoImpl rrd = new ReimburstmentRequestDaoImpl();
		rrd.submitReimburstmentRequest(new ReimburstmentRequest(amount, date, 1, Service.currentUser.getUserID(), description, blob));
	}

}
